﻿namespace Cars.Test.CarsRepositoryMocked
{
    using Cars.Contracts;

    public interface ICarsRepositoryMocked
    {
        ICarsRepository CarsDataRepository { get; }
    }
}
