﻿namespace IntergalacticTravel.Contracts
{
    public interface INameable
    {
        string Name { get; }
    }
}
