﻿namespace BunniesSpace
{
    public enum FurType
    {
        NotFluffy,
        ALittleFluffy,
        Fluffy,
        FluffyToTheLimit
    }
}
